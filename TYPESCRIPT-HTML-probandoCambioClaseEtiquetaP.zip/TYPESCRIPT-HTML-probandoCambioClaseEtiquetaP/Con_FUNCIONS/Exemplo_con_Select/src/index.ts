import { selecionDato } from "./funcions";
selecionDato()



