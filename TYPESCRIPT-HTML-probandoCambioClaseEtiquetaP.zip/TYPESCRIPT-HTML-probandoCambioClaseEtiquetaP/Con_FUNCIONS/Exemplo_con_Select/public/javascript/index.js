import { selecionDato } from "./funcions.js";
selecionDato();
