import { BloqueEnlace } from "./BloqueEnlace";

class EtiquetaA extends BloqueEnlace{

    constructor(etiqueta: string){
        super(etiqueta)
        
    }
    
    
}

export {EtiquetaA}