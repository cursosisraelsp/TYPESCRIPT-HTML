import { CrearEPintarElemento } from "./Clases/CrearEPintarElemento.js";
const instancia = new CrearEPintarElemento("div");
instancia.creoEtiqueta();
