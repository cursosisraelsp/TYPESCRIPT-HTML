import { CrearEPintarElemento } from "./Clases/CrearEPintarElemento";

const instancia = new CrearEPintarElemento("div")
instancia.creoEtiqueta()