# Antes de comenzar

Comenzo sobre cómo estructurar o exercicio grande


## Clases a crear 

### Abstractas ?

> Etiqueta : posiblemente sexa unha ``clase abstracta``


> De Bloque: esta é unha idea de crear diferentes clases para o desenrolo de bloques de información.



| Bloque   |      Páxinas      |  
|----------|:-------------:|
| Botón |  Home | $1600 |
| Formulario |    Settings, New Product   |   
| Tablas | Customers, Invoices, New Invoice | 
| Menús | --- |


## Clases