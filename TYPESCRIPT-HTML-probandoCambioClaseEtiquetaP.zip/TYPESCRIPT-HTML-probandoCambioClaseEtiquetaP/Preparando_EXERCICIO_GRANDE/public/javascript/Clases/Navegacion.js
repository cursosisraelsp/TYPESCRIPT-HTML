class Navegacion {
    constructor(etiquetaA, etiquetaImg, etiquetaDiv) {
        this.etiquetaA = etiquetaA;
        this.etiquetaImg = etiquetaImg;
        this.etiquetaDiv = etiquetaDiv;
    }
}
export { Navegacion };
