class LinksPaxinas {
}
export { LinksPaxinas };
