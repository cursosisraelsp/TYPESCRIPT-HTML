abstract class LinksPaxinas{
   
    abstract etiquetaDiv(): HTMLDivElement; // O contedor dos elementos
    abstract etiquetaA() : HTMLAnchorElement;
    abstract etiquetaImg() : HTMLImageElement;
}

export {LinksPaxinas}


